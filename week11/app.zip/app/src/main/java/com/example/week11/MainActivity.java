package com.example.week11;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private Storage storage;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        storage = Storage.getInstance();
        recyclerView = findViewById(R.id.ListOfThings);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new ProductAdapter(getApplicationContext(), storage.getProducts()));
    }

    @Override
    protected void onResume() {
        super.onResume();
        recyclerView.setAdapter(new ProductAdapter(getApplicationContext(), storage.getProducts()));
    }

    public void addProduct(View view){
        storage.addProduct(new Product("Empty", 0));
        onResume();
    }

    public void sortId(View view){
        storage.sortId();
        onResume();
    }
    public void sortAlpha(View view){
        storage.sortAlpha();
        onResume();
    }

}












